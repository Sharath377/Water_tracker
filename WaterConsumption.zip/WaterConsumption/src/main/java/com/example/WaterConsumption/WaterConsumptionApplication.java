package com.example.WaterConsumption;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WaterConsumptionApplication {

	public static void main(String[] args) {
		SpringApplication.run(WaterConsumptionApplication.class, args);
	}

}
