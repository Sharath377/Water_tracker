package com.example.WaterConsumption;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WaterConsumptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
